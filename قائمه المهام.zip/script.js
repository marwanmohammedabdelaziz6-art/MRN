let head = document.getElementById("head");
let taskInput = document.getElementById("taskInput");
let Btn = document.getElementById("Btn");
let massege = document.getElementById("massege");
let pgh = document.getElementById("pgh");
let list = document.getElementById("list");

let count = 0;
Btn.addEventListener("click", function(){
  let taskText = taskInput.value;
  if (taskText === ""){
    massege.textContent = "please enter a task";
    return;
  };
  taskInput.value = "";
  count++;
  pgh.textContent = count;
  
  let li = document.createElement("li");
  let spanText = document.createElement("span");
  spanText.textContent = taskText;
  
  let noteInput = document.createElement("input");
  noteInput.type = "text";
  noteInput.placeholder = "enter a note";
  
  
  let delateBtn = document.createElement("button");
  delateBtn.textContent = "Delate";
  
  
  li.appendChild(spanText);
  li.appendChild(noteInput);
  li.appendChild(delateBtn);
  list.appendChild(li);
massege.textContent = "add Successfuly";
  delateBtn.addEventListener("click" , function(){
    li.remove();
    count--;
    pgh.textContent = count;
    
    massege.textContent = "Task Delated";
  });
});
